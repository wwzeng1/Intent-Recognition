BATCH_SIZE = 124
EPOCHS = 10000
vocab_file_path = 'vocab.json'
WARMUP = 16000

em_size = 128
num_heads = 4
hid_dim = 1024
nencoderlayers = 6
dout = 0.15
